# Import all the models here for Alembic
from app.database.session import Base
from app.models.user import User
from app.models.beacon import Beacon
from app.models.presence_log import PresenceLog
