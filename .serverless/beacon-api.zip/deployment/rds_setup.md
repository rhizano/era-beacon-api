# AWS RDS PostgreSQL Setup Guide

## Creating RDS Instance (Free Tier)

### 1. Navigate to RDS Console
1. Go to AWS RDS Console
2. Click "Create database"

### 2. Database Creation Settings

#### Engine Options
- **Engine type**: PostgreSQL
- **Version**: PostgreSQL 14.x (latest stable)

#### Templates
- **Template**: Free tier

#### Settings
- **DB instance identifier**: `beacon-api-db`
- **Master username**: `beacon_admin`
- **Master password**: Generate or create a strong password

#### DB Instance Class
- **Instance class**: db.t3.micro (free tier eligible)

#### Storage
- **Storage type**: General Purpose SSD (gp2)
- **Allocated storage**: 20 GB (free tier limit)
- **Enable storage autoscaling**: Uncheck (to stay in free tier)

#### Connectivity
- **VPC**: Default VPC
- **Subnet group**: default
- **Public access**: Yes (for initial setup, restrict later)
- **VPC security groups**: Create new
  - **Name**: `beacon-api-db-sg`

#### Additional Configuration
- **Initial database name**: `beacon_api`
- **DB parameter group**: default
- **Backup retention period**: 7 days
- **Maintenance window**: Choose a suitable time
- **Delete protection**: Enable

### 3. Security Group Configuration

After creation, update the security group:

1. Go to EC2 Console > Security Groups
2. Find `beacon-api-db-sg`
3. Edit inbound rules:
   - **Type**: PostgreSQL
   - **Port**: 5432
   - **Source**: Your EC2 security group or specific IP

### 4. Connection String

Your DATABASE_URL will be:
```
postgresql://beacon_admin:your_password@your-rds-endpoint.region.rds.amazonaws.com:5432/beacon_api
```

### 5. Testing Connection

From your EC2 instance:
```bash
# Install PostgreSQL client (if not already installed)
sudo yum install postgresql -y

# Test connection
psql -h your-rds-endpoint.region.rds.amazonaws.com -U beacon_admin -d beacon_api

# Test from Python
python3 -c "
import psycopg2
conn = psycopg2.connect(
    host='your-rds-endpoint',
    database='beacon_api',
    user='beacon_admin',
    password='your_password'
)
print('Connection successful!')
conn.close()
"
```

## Alternative: SQLite for Development

For minimal cost during development, you can use SQLite:

```bash
# In .env file
DATABASE_URL=sqlite:///./beacon_api.db
```

## Cost Management

### Free Tier Limits
- **Hours**: 750 hours per month (enough for 24/7 operation)
- **Storage**: 20 GB
- **Backup storage**: 20 GB

### Monitoring
- Set up CloudWatch billing alerts
- Monitor RDS usage in AWS console
- Use AWS Cost Explorer

### Optimization Tips
1. **Stop/Start**: You can stop RDS for up to 7 days to save costs
2. **Backup management**: Automatic backups are included in free tier
3. **Monitoring**: Use CloudWatch to track performance

## Security Best Practices

### 1. Network Security
```bash
# Create dedicated security group for RDS
aws ec2 create-security-group \
    --group-name beacon-api-db-sg \
    --description "Security group for Beacon API database"

# Allow PostgreSQL access only from application security group
aws ec2 authorize-security-group-ingress \
    --group-id sg-xxxxxxxxx \
    --protocol tcp \
    --port 5432 \
    --source-group sg-yyyyyyyyy
```

### 2. Secrets Management
Use AWS Secrets Manager for production:

```python
# app/core/config.py
import boto3
import json

def get_secret(secret_name):
    client = boto3.client('secretsmanager')
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

# In production
if not settings.debug:
    db_secret = get_secret('beacon-api/database')
    DATABASE_URL = f"postgresql://{db_secret['username']}:{db_secret['password']}@{db_secret['host']}:5432/{db_secret['dbname']}"
```

### 3. SSL/TLS
Enable SSL connections:

```python
# Update DATABASE_URL for SSL
DATABASE_URL=postgresql://user:pass@host:5432/db?sslmode=require
```

## Troubleshooting

### Common Issues

1. **Connection Timeout**
   - Check security groups
   - Verify VPC settings
   - Ensure public accessibility if connecting from outside AWS

2. **Authentication Failed**
   - Verify username/password
   - Check if user has proper permissions

3. **SSL Errors**
   - Add `?sslmode=require` to connection string
   - Download RDS root certificate if needed

### Useful Commands

```bash
# Check RDS instances
aws rds describe-db-instances

# Create database backup
aws rds create-db-snapshot \
    --db-instance-identifier beacon-api-db \
    --db-snapshot-identifier beacon-api-backup-$(date +%Y%m%d)

# Monitor connections
psql -h your-endpoint -U beacon_admin -d beacon_api -c "
SELECT 
    datname,
    usename,
    application_name,
    client_addr,
    state
FROM pg_stat_activity 
WHERE datname = 'beacon_api';
"
```
