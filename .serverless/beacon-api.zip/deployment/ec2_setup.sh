#!/bin/bash

# AWS EC2 Setup Script for BLE Beacon API
# Run this script on a fresh Amazon Linux 2 EC2 instance

set -e

echo "🚀 Setting up BLE Beacon API on AWS EC2..."

# Update system
echo "📦 Updating system packages..."
sudo yum update -y

# Install Python 3.9, pip, git, and other dependencies
echo "🐍 Installing Python 3.9 and dependencies..."
sudo yum install python3.9 python3.9-pip git nginx htop -y

# Install PostgreSQL client
sudo yum install postgresql -y

# Create application user
echo "👤 Creating application user..."
sudo useradd -m -s /bin/bash beacon-api
sudo usermod -aG wheel beacon-api

# Create application directory
echo "📁 Setting up application directory..."
sudo mkdir -p /opt/beacon-api
sudo chown beacon-api:beacon-api /opt/beacon-api

# Switch to application user
sudo -u beacon-api bash << 'EOF'
cd /opt/beacon-api

# Clone repository (replace with your repo URL)
echo "📥 Cloning repository..."
git clone https://github.com/your-username/era-beacon-api.git .

# Create virtual environment
echo "🔧 Setting up Python virtual environment..."
python3.9 -m venv venv
source venv/bin/activate

# Install Python dependencies
echo "📚 Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt
pip install gunicorn supervisor

# Create production environment file
echo "⚙️ Creating production environment..."
cat > .env << 'ENVEOF'
# Production Environment - Update these values
DATABASE_URL=postgresql://username:password@your-rds-endpoint:5432/beacon_api
SECRET_KEY=your-super-secret-production-key-change-this
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
API_V1_STR=/v1
PROJECT_NAME=BLE Beacon Presence Tracking API
DEBUG=False
HOST=0.0.0.0
PORT=8000
ENVEOF

echo "📋 Please update the .env file with your actual database credentials!"
EOF

# Create systemd service file
echo "🔧 Creating systemd service..."
sudo tee /etc/systemd/system/beacon-api.service > /dev/null << 'EOF'
[Unit]
Description=BLE Beacon API
After=network.target

[Service]
Type=exec
User=beacon-api
Group=beacon-api
WorkingDirectory=/opt/beacon-api
Environment="PATH=/opt/beacon-api/venv/bin"
ExecStart=/opt/beacon-api/venv/bin/gunicorn app.main:app --bind 127.0.0.1:8000 --workers 2 --worker-class uvicorn.workers.UvicornWorker
ExecReload=/bin/kill -s HUP $MAINPID
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Configure Nginx as reverse proxy
echo "🌐 Configuring Nginx..."
sudo tee /etc/nginx/conf.d/beacon-api.conf > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;  # Replace with your domain

    client_max_body_size 4M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Remove default Nginx config
sudo rm -f /etc/nginx/nginx.conf.default

# Create log directory
sudo mkdir -p /var/log/beacon-api
sudo chown beacon-api:beacon-api /var/log/beacon-api

# Enable and start services
echo "🔄 Enabling services..."
sudo systemctl daemon-reload
sudo systemctl enable beacon-api
sudo systemctl enable nginx

# Start Nginx
sudo systemctl start nginx

echo "✅ Setup complete!"
echo ""
echo "📝 Next Steps:"
echo "1. Update /opt/beacon-api/.env with your RDS database credentials"
echo "2. Run database migrations: sudo -u beacon-api bash -c 'cd /opt/beacon-api && source venv/bin/activate && alembic upgrade head'"
echo "3. Start the API service: sudo systemctl start beacon-api"
echo "4. Check service status: sudo systemctl status beacon-api"
echo "5. View logs: sudo journalctl -u beacon-api -f"
echo ""
echo "🌍 Your API will be available at: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)"
echo "📖 API Documentation: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)/v1/docs"
