# AWS Deployment - Quick Start

## Option 1: AWS Lambda (Serverless) - Recommended for Free Tier

### Prerequisites
- AWS Account
- Node.js installed
- AWS CLI configured

### Step 1: Install Dependencies
```bash
# Install Node.js dependencies for serverless
npm install

# Install serverless globally
npm install -g serverless

# Add Lambda adapter to Python requirements
echo "mangum==0.17.0" >> requirements.txt
```

### Step 2: Configure AWS
```bash
# Configure AWS CLI
aws configure

# Or set environment variables
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-east-1
```

### Step 3: Set Environment Variables
```bash
# Create production environment
export DATABASE_URL="postgresql://user:pass@rds-endpoint:5432/beacon_api"
export SECRET_KEY="your-super-secret-production-key"
```

### Step 4: Deploy
```bash
# Deploy to AWS
serverless deploy

# Your API will be available at the returned endpoint
# Example: https://abc123.execute-api.us-east-1.amazonaws.com/dev
```

## Option 2: AWS EC2 - Traditional Deployment

### Step 1: Launch EC2 Instance
1. **Instance Type**: t2.micro (Free Tier)
2. **AMI**: Amazon Linux 2
3. **Security Group**: Allow HTTP (80), HTTPS (443), SSH (22)

### Step 2: Setup Instance
```bash
# Upload setup script to EC2
scp -i your-key.pem deployment/ec2_setup.sh ec2-user@your-ec2-ip:~/

# Connect and run setup
ssh -i your-key.pem ec2-user@your-ec2-ip
chmod +x ec2_setup.sh
sudo ./ec2_setup.sh
```

### Step 3: Configure Database
Follow the RDS setup guide in `deployment/rds_setup.md`

### Step 4: Update Configuration
```bash
# Edit environment file
sudo -u beacon-api nano /opt/beacon-api/.env

# Update with your RDS credentials
DATABASE_URL=postgresql://username:password@your-rds-endpoint:5432/beacon_api
SECRET_KEY=your-production-secret-key
```

### Step 5: Start Services
```bash
# Run database migrations
sudo -u beacon-api bash -c 'cd /opt/beacon-api && source venv/bin/activate && alembic upgrade head'

# Start the API service
sudo systemctl start beacon-api
sudo systemctl status beacon-api

# Your API will be available at: http://your-ec2-ip
```

## Free Tier Cost Breakdown

### Lambda Option (Recommended)
- **API Gateway**: 1M requests/month free
- **Lambda**: 1M requests + 400,000 GB-seconds/month free
- **RDS**: 750 hours + 20GB storage/month free
- **Estimated Monthly Cost**: $0-5 (within free tier limits)

### EC2 Option
- **EC2 t2.micro**: 750 hours/month free (12 months)
- **RDS db.t3.micro**: 750 hours/month free
- **Storage**: 30GB EBS + 20GB RDS free
- **Data Transfer**: 1GB/month free
- **Estimated Monthly Cost**: $0-10 (within free tier limits)

## Security Setup

### 1. Environment Variables
Store sensitive data in AWS Systems Manager Parameter Store:

```bash
# Store database URL
aws ssm put-parameter \
    --name "/beacon-api/database-url" \
    --value "postgresql://user:pass@host:5432/db" \
    --type "SecureString"

# Store secret key
aws ssm put-parameter \
    --name "/beacon-api/secret-key" \
    --value "your-secret-key" \
    --type "SecureString"
```

### 2. Database Security
- Use RDS with security groups
- Enable SSL connections
- Regular backups enabled
- Restrict access to application subnets only

### 3. API Security
- Use HTTPS with AWS Certificate Manager
- Implement rate limiting
- Enable CloudWatch logging
- Set up monitoring alerts

## Monitoring and Maintenance

### CloudWatch Setup
```bash
# Create log group
aws logs create-log-group --log-group-name /aws/lambda/beacon-api

# Set up billing alerts
aws cloudwatch put-metric-alarm \
    --alarm-name "beacon-api-billing" \
    --alarm-description "Billing alert for beacon API" \
    --metric-name EstimatedCharges \
    --namespace AWS/Billing \
    --statistic Maximum \
    --period 86400 \
    --threshold 10 \
    --comparison-operator GreaterThanThreshold
```

### Health Checks
The API includes a health endpoint at `/health` for monitoring.

## Troubleshooting

### Lambda Issues
```bash
# View logs
serverless logs -f api -t

# Check function details
aws lambda get-function --function-name beacon-api-dev-api
```

### EC2 Issues
```bash
# Check service status
sudo systemctl status beacon-api

# View logs
sudo journalctl -u beacon-api -f

# Test database connection
sudo -u beacon-api bash -c 'cd /opt/beacon-api && source venv/bin/activate && python -c "from app.database.session import engine; print(engine.execute(\"SELECT 1\").scalar())"'
```

## Next Steps

1. **Domain Setup**: Configure custom domain with Route 53
2. **SSL Certificate**: Use AWS Certificate Manager for HTTPS
3. **CI/CD**: GitHub Actions workflow is included
4. **Monitoring**: Set up CloudWatch dashboards
5. **Scaling**: Configure auto-scaling when traffic grows

## Support

- AWS Free Tier documentation: https://aws.amazon.com/free/
- FastAPI deployment guides: https://fastapi.tiangolo.com/deployment/
- Serverless Framework: https://www.serverless.com/framework/docs/
